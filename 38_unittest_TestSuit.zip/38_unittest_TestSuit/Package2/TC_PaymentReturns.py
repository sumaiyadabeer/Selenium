import unittest
#from selenium import webdriver

class PaymentReturnsTest(unittest.TestCase):

	def test_paymentreturnbybank(self):
		print("this is payment return by bank test")
		self.assertTrue(True)

if __name__== "__main__":
	unittest.main()
